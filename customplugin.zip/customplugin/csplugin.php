<?php
/**
 * @package Custom plugin
 * @version 1.7.2
 */
/*
Plugin Name: Csplugin
Plugin URI: http://wordpress.org/plugins/csplugin/
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
Author: tej pandya
Version: 1.7.2
Author URI: http://ma.tt/
*/

register_deactivation_hook( __FILE__, 'addAdminPageContent');

register_activation_hook( __FILE__, 'registration_form');

add_action('admin_menu', 'addAdminPageContent');
function addAdminPageContent() {
  add_menu_page('Add New Product', 'Add New Product', 'manage_options', __FILE__, 'registration_form', 'dashicons-wordpress');
}

function registration_form() {
 
    global $wpdb;
  $table_name = $wpdb->prefix . 'userstable';

    echo '
    <style>
    div {
        margin-bottom:2px;
    }
     
    input{
        margin-bottom:4px;
    }
    </style>
    ';
 
    echo '<section class="container">
        <form action="" method="post">
        <table cellspacing="5px" cellpadding="5%"; align="center">
            <center><h1>Registration Form</h1></center>
            <tr>
            <td><label for="title">Title <strong>*</strong></label></td>
            <td><input type="text" name="title" value=""></td>
            </tr>
             
            <tr> 
            <td><label for="description">Description</label></td>
            <td><textarea name="description"></textarea></td>
            </tr>

            <tr>
            <td><label for="availiability">Availiability:</label></td>
        	<td><input type="checkbox" id="client" name="chkl[]" value="client"><label for="client">Client</label>
        	<input type="checkbox" id="distributor" name="chkl[]" value="distributor"><label for="distributor">Distributor</label>
            </td>
            </tr>

            <tr>
            <td><label for="mfb">Manufucture by:</label></td>
        	<td><select name="mfb">
        	  <option value="krishna">Krisha Pvt ltd</option>
        	  <option value="saab">Saab ltd</option>
        	  <option value="opel">Opel pvt</option>
        	  <option value="audi">Audi ltd</option>
        	</select></td>
            </tr>

            <tr>
            <td><label>Featured Product:</label></td>
            <td><input type="radio" id="radio" name="fp" value="Yes"><label for="yes">Yes</label>
                <input type="radio" id="radio" name="fp" value="No"><label for="no">No</label>
            </td>
            </tr>

            <tr>
            <td><label for="price">Price</label></td>
            <td><input type="number" name="price" value=""></td>
            </tr>

            <tr>
            <td></td>
            <td><input type="submit" name="submit" value="Register"/></td>
            </tr>

        </table>
        </form>
    </section>';

        global $wpdb;
        if ( isset( $_POST['submit'] ) ){
            $title = $_POST['title'];
            $description = $_POST['description'];
            $checkbox1 =  $_POST['chkl'];
            $manufacture = $_POST['mfb'];
            $feturedp = $_POST['fp'];
            $price = $_POST['price'];

            $chk="";  
            foreach($checkbox1 as $chk1)  
               {  
                  $chk .= $chk1.",";  
               }  

            $table_name = $wpdb->prefix . "userstable";
            $qury = $wpdb->insert( $table_name, array(
                'title' => $title,
                'description' => $description,
                'availiability' => $chk,
                'manufacture' => $manufacture,
                'featuredp' => $feturedp,
                'price' => $price
            ) );

            if($qury==1)  
           {  
              echo'<script>alert("Inserted Successfully")</script>';  
           }  
        else  
           {  
              echo'<script>alert("Failed To Insert")</script>';  
           }
        }
}
?>
